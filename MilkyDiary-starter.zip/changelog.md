# Changelog

## v0.1.0
- Initial project scaffold.
- Added Geode load confirmation.
- Added Android 64-bit GitHub Actions build workflow.
- No game visuals are changed yet.
