#include <Geode/Geode.hpp>

using namespace geode::prelude;

// Milky Diary v0.1.0: initial load test.
// Menu and gameplay visual replacements will be added in later milestones.
$on_mod(Loaded) {
    log::info("Milky Diary loaded successfully.");
}
