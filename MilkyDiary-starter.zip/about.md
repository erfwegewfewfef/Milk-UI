# Milky Diary

A pastel scrapbook-inspired visual overhaul for Geometry Dash.

The goal is to replace the game's visual identity with a cozy diary aesthetic:
cream paper, powder pink, pale lavender, tiny stars, flowers, bows and soft
handmade details. Development is split into small milestones so each change
can be tested before the next one is added.
