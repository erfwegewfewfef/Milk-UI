# Milky Diary

A full visual-overhaul project for Geometry Dash, with a pastel diary / scrapbook
art direction: warm paper, powder pink, pale lavender, ribbons, flowers and
hand-drawn stars.

## Current status

**v0.1.0 is only a starter scaffold.** It checks the Geode project structure and
prints a message when loaded. It does not yet reskin menus or gameplay.

## Planned milestones

- v0.1: buildable project scaffold and Android CI
- v0.2: main menu and level browser
- v0.3: popups, buttons, profiles, shops and rewards
- v0.4: gameplay HUD, pause, death and completion screens
- v0.5: decorative animations, textures and polish

## Target reported by the player

- Geode app: 1.9.0
- Geometry Dash Android: 2.2.144 (reported version; verify compatibility during CI)

## Build

This repository uses the official `geode-sdk/build-geode-mod` GitHub Action
to build an Android 64-bit `.geode` artifact.

Official docs:
https://docs.geode-sdk.org/getting-started/create-mod/
